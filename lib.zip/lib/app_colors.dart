import 'package:flutter/material.dart';

class AppColors {
  static const Color navy = Color(0xFF0A1929);
  static const Color navyLight = Color(0xFF112240);
  static const Color navyCard = Color(0xFF132F4C);
  static const Color accent = Color(0xFF3B82F6);
  static const Color accentLight = Color(0xFF60A5FA);
  static const Color textPrimary = Color(0xFFE6F1FF);
  static const Color textSecondary = Color(0xFF8892B0);
  static const Color error = Color(0xFFFF6B6B);
  static const Color border = Color(0xFF233554);
}
