import 'package:flutter/material.dart';

class TaskItem {
  final String title;
  final String category;
  final String time;
  final int priority; // 0 = Low, 1 = Medium, 2 = High
  bool done;

  TaskItem({
    required this.title,
    required this.category,
    required this.time,
    required this.priority,
    this.done = false,
  });
}

class HabitItem {
  final String name;
  final IconData icon;
  final int streak;
  bool done;

  HabitItem({
    required this.name,
    required this.icon,
    required this.streak,
    this.done = false,
  });
}

Color priorityColor(int p) {
  switch (p) {
    case 2:
      return const Color(0xFFFF6B6B);
    case 1:
      return Colors.amber;
    default:
      return Colors.greenAccent;
  }
}

String priorityLabel(int p) {
  switch (p) {
    case 2:
      return 'High';
    case 1:
      return 'Medium';
    default:
      return 'Low';
  }
}