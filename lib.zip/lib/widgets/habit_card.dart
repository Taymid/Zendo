import 'package:flutter/material.dart';

import '../app_colors.dart';
import '../models.dart';

class HabitCard extends StatelessWidget {
  final HabitItem habit;
  final VoidCallback onToggle;

  const HabitCard({super.key, required this.habit, required this.onToggle});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onToggle,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: 118,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: habit.done
              ? AppColors.accent.withValues(alpha: 0.16)
              : AppColors.navyCard,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: habit.done ? AppColors.accent : AppColors.border,
            width: 1.2,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 38,
              width: 38,
              decoration: BoxDecoration(
                color: habit.done ? AppColors.accent : AppColors.navyLight,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                habit.done ? Icons.check_rounded : habit.icon,
                color: habit.done ? Colors.white : AppColors.accentLight,
                size: 20,
              ),
            ),
            const Spacer(),
            Text(
              habit.name,
              style: const TextStyle(
                color: AppColors.textPrimary,
                fontSize: 13.5,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 5),
            Row(
              children: [
                const Icon(
                  Icons.local_fire_department_rounded,
                  color: Colors.orangeAccent,
                  size: 14,
                ),
                const SizedBox(width: 3),
                Text(
                  '${habit.streak} days',
                  style: const TextStyle(
                    color: AppColors.textSecondary,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
