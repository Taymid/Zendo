import 'package:flutter/material.dart';
import '../app_colors.dart';

class ProgressCard extends StatelessWidget {
  final int doneCount;
  final int totalCount;
  final double completion;
  final int bestStreak;

  const ProgressCard({
    super.key,
    required this.doneCount,
    required this.totalCount,
    required this.completion,
    required this.bestStreak,
  });

  @override
  Widget build(BuildContext context) {
    final remaining = totalCount - doneCount;
    final allDone = doneCount == totalCount && totalCount > 0;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppColors.navyCard, AppColors.navyLight],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.border, width: 1.2),
      ),
      child: Row(
        children: [
          SizedBox(
            height: 92,
            width: 92,
            child: Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  height: 92,
                  width: 92,
                  child: CircularProgressIndicator(
                    value: completion,
                    strokeWidth: 8,
                    strokeCap: StrokeCap.round,
                    backgroundColor: AppColors.border,
                    valueColor: const AlwaysStoppedAnimation<Color>(
                      AppColors.accentLight,
                    ),
                  ),
                ),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '${(completion * 100).round()}%',
                      style: const TextStyle(
                        color: AppColors.textPrimary,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Text(
                      'done',
                      style: TextStyle(
                        color: AppColors.textSecondary,
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 22),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Daily Progress',
                  style: TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  allDone
                      ? 'All tasks complete. Great work!'
                      : '$remaining task${remaining == 1 ? '' : 's'} left today',
                  style: const TextStyle(
                    color: AppColors.textSecondary,
                    fontSize: 13,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    const Icon(
                      Icons.local_fire_department_rounded,
                      color: Colors.orangeAccent,
                      size: 18,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      '$bestStreak day best streak',
                      style: const TextStyle(
                        color: AppColors.textSecondary,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}