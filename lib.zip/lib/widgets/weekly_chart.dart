import 'package:flutter/material.dart';

import '../app_colors.dart';

class WeeklyChart extends StatelessWidget {
  const WeeklyChart({super.key});

  static const _values = [4, 6, 3, 7, 5, 2, 4];
  static const _labels = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
  static const _maxValue = 7.0;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 20, 18, 14),
      decoration: BoxDecoration(
        color: AppColors.navyCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border, width: 1.2),
      ),
      child: SizedBox(
        height: 120,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: List.generate(7, (i) {
            final barHeight = (_values[i] / _maxValue) * 78;
            final isToday = i == DateTime.now().weekday - 1;

            return Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    '${_values[i]}',
                    style: TextStyle(
                      color: isToday
                          ? AppColors.accentLight
                          : AppColors.textSecondary,
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Container(
                    height: barHeight.clamp(8.0, 78.0),
                    width: 18,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                        colors: isToday
                            ? [AppColors.accent, AppColors.accentLight]
                            : [
                                AppColors.accent.withValues(alpha: 0.45),
                                AppColors.accentLight.withValues(alpha: 0.70),
                              ],
                      ),
                      borderRadius: BorderRadius.circular(6),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _labels[i],
                    style: TextStyle(
                      color: isToday
                          ? AppColors.accentLight
                          : AppColors.textSecondary,
                      fontSize: 11,
                      fontWeight: isToday ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                ],
              ),
            );
          }),
        ),
      ),
    );
  }
}
