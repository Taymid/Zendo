import 'package:flutter/material.dart';
import '../app_colors.dart';

class AppBottomNavBar extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;

  const AppBottomNavBar({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  static const List<String> titles = [
    'Home',
    'Tasks',
    'Calendar',
    'Focus',
    'Dashboard',
  ];

  static const List<IconData> icons = [
    Icons.home_rounded,
    Icons.checklist_rtl_rounded,
    Icons.calendar_month_rounded,
    Icons.timer_outlined,
    Icons.insights_rounded,
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.navyLight,
        border: Border(top: BorderSide(color: AppColors.border, width: 1)),
      ),
      child: BottomNavigationBar(
        currentIndex: currentIndex,
        onTap: onTap,
        backgroundColor: Colors.transparent,
        elevation: 0,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: AppColors.accentLight,
        unselectedItemColor: AppColors.textSecondary,
        selectedFontSize: 11,
        unselectedFontSize: 11,
        selectedLabelStyle: const TextStyle(fontWeight: FontWeight.w600),
        items: List.generate(
          titles.length,
          (i) => BottomNavigationBarItem(
            icon: Icon(icons[i], size: 24),
            label: titles[i],
          ),
        ),
      ),
    );
  }
}