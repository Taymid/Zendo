import 'package:flutter/material.dart';

import 'app_colors.dart';
import 'models.dart';
import 'widgets/add_task_sheet.dart';
import 'widgets/bottom_nav_bar.dart';
import 'widgets/coming_soon.dart';
import 'widgets/focus_card.dart';
import 'widgets/habit_card.dart';
import 'widgets/home_header.dart';
import 'widgets/progress_card.dart';
import 'widgets/section_title.dart';
import 'widgets/stat_card.dart';
import 'widgets/task_card.dart';
import 'widgets/weekly_chart.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _navIndex = 0;
  static const _userName = 'Tahmid';

  final List<TaskItem> _tasks = [
    TaskItem(
      title: 'Review Chapter 4 — Algorithms',
      category: 'Study',
      time: '09:00',
      priority: 2,
    ),
    TaskItem(
      title: 'Finish SRS revision',
      category: 'Work',
      time: '13:30',
      priority: 2,
      done: true,
    ),
    TaskItem(
      title: '30 min workout',
      category: 'Health',
      time: '18:00',
      priority: 1,
    ),
    TaskItem(
      title: 'Read 20 pages',
      category: 'Personal',
      time: '21:00',
      priority: 0,
    ),
  ];

  final List<HabitItem> _habits = [
    HabitItem(name: 'Reading', icon: Icons.menu_book_rounded, streak: 12),
    HabitItem(name: 'Exercise', icon: Icons.fitness_center_rounded, streak: 5),
    HabitItem(name: 'Sleep 8h', icon: Icons.bedtime_rounded, streak: 3),
  ];

  int get _doneCount => _tasks.where((t) => t.done).length;
  double get _completion => _tasks.isEmpty ? 0 : _doneCount / _tasks.length;
  int get _bestStreak => _habits.isEmpty
      ? 0
      : _habits.map((h) => h.streak).reduce((a, b) => a > b ? a : b);

  String get _greeting {
    final h = DateTime.now().hour;
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  }

  String get _todayLabel {
    const days = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
      'Sunday',
    ];
    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
    final now = DateTime.now();
    return '${days[now.weekday - 1]}, ${now.day} ${months[now.month - 1]}';
  }

  void _toggleTask(int i) => setState(() => _tasks[i].done = !_tasks[i].done);
  void _toggleHabit(int i) =>
      setState(() => _habits[i].done = !_habits[i].done);

  void _deleteTask(int i) {
    final removed = _tasks[i];
    setState(() => _tasks.removeAt(i));
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text('Deleted "${removed.title}"'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: AppColors.navyCard,
          action: SnackBarAction(
            label: 'UNDO',
            textColor: AppColors.accentLight,
            onPressed: () => setState(
              () => _tasks.insert(i.clamp(0, _tasks.length), removed),
            ),
          ),
        ),
      );
  }

  void _startFocus() {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        const SnackBar(
          content: Text('Focus session started: 25 min'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: AppColors.navyCard,
        ),
      );
  }

  Future<void> _openAddTaskSheet() async {
    final newTask = await showAddTaskSheet(context);
    if (newTask != null) setState(() => _tasks.add(newTask));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.navy,
      body: SafeArea(
        bottom: false,
        child: _navIndex == 0
            ? _buildHome()
            : ComingSoon(
                title: AppBottomNavBar.titles[_navIndex],
                icon: AppBottomNavBar.icons[_navIndex],
              ),
      ),
      floatingActionButton: _navIndex == 0
          ? FloatingActionButton(
              onPressed: _openAddTaskSheet,
              backgroundColor: AppColors.accent,
              foregroundColor: Colors.white,
              elevation: 4,
              child: const Icon(Icons.add_rounded, size: 28),
            )
          : null,
      bottomNavigationBar: AppBottomNavBar(
        currentIndex: _navIndex,
        onTap: (i) => setState(() => _navIndex = i),
      ),
    );
  }

  Widget _buildHome() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 100),
      children: [
        HomeHeader(
          greeting: _greeting,
          todayLabel: _todayLabel,
          userName: _userName,
        ),
        const SizedBox(height: 24),
        ProgressCard(
          doneCount: _doneCount,
          totalCount: _tasks.length,
          completion: _completion,
          bestStreak: _bestStreak,
        ),
        const SizedBox(height: 16),
        _buildStatsGrid(),
        const SizedBox(height: 28),
        SectionTitle(
          title: 'Today\'s Tasks',
          trailing: '$_doneCount/${_tasks.length} done',
        ),
        const SizedBox(height: 14),
        _buildTaskList(),
        const SizedBox(height: 28),
        const SectionTitle(title: 'Habits', trailing: 'View history'),
        const SizedBox(height: 14),
        _buildHabitRow(),
        const SizedBox(height: 28),
        const SectionTitle(title: 'Focus', trailing: '25 / 5 min'),
        const SizedBox(height: 14),
        FocusCard(onStart: _startFocus),
        const SizedBox(height: 28),
        const SectionTitle(title: 'This Week', trailing: 'Completed tasks'),
        const SizedBox(height: 14),
        const WeeklyChart(),
        const SizedBox(height: 20),
      ],
    );
  }

  Widget _buildStatsGrid() {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: StatCard(
                icon: Icons.task_alt_rounded,
                value: '$_doneCount',
                label: 'Tasks Done',
                color: Colors.greenAccent,
              ),
            ),
            const SizedBox(width: 14),
            const Expanded(
              child: StatCard(
                icon: Icons.timer_outlined,
                value: '95m',
                label: 'Focus Time',
                color: AppColors.accentLight,
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        const Row(
          children: [
            Expanded(
              child: StatCard(
                icon: Icons.flag_outlined,
                value: '3',
                label: 'Active Goals',
                color: Colors.orangeAccent,
              ),
            ),
            SizedBox(width: 14),
            Expanded(
              child: StatCard(
                icon: Icons.phone_android_rounded,
                value: '1h 42m',
                label: 'Screen Time',
                color: AppColors.error,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildTaskList() {
    if (_tasks.isEmpty) {
      return Container(
        padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 20),
        decoration: BoxDecoration(
          color: AppColors.navyCard,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          children: const [
            Icon(Icons.inbox_rounded, color: AppColors.textSecondary, size: 40),
            SizedBox(height: 12),
            Text(
              'No tasks yet',
              style: TextStyle(
                color: AppColors.textPrimary,
                fontSize: 15,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 6),
            Text(
              'Tap the + button to create your first task',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.textSecondary, fontSize: 12),
            ),
          ],
        ),
      );
    }

    return Column(
      children: List.generate(
        _tasks.length,
        (i) => Dismissible(
          key: ObjectKey(_tasks[i]),
          direction: DismissDirection.endToStart,
          onDismissed: (_) => _deleteTask(i),
          background: Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.only(right: 22),
            alignment: Alignment.centerRight,
            decoration: BoxDecoration(
              color: AppColors.error.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(18),
            ),
            child: const Icon(
              Icons.delete_outline_rounded,
              color: AppColors.error,
            ),
          ),
          child: TaskCard(task: _tasks[i], onToggle: () => _toggleTask(i)),
        ),
      ),
    );
  }

  Widget _buildHabitRow() {
    return SizedBox(
      height: 128,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: _habits.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (_, i) =>
            HabitCard(habit: _habits[i], onToggle: () => _toggleHabit(i)),
      ),
    );
  }
}
